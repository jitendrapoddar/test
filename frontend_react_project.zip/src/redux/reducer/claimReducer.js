import React from 'react'


const initialState = {
    claimSummaryCardHeader : 'Absence/Claim Summary',
    employeeName : 'Jitendra',
    claimNumber : '123',
    claimType : 'abc',
    claimPrograms : '123',
    claimStartDate : '2020-08-01',
    claimEndDate : '2020-08-01',
    mainFlag : false
}

const claimReducer = (state = initialState, action) => {
    switch(action.type){
        default: return state
    }
}

export default claimReducer


