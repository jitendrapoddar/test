import {createStore} from 'redux'
import claimReducer from '../reducer/claimReducer'

const store = createStore(claimReducer)

export default store