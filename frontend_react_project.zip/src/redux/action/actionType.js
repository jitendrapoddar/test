export const CANCEL = 'CANCLE'
export const NEXT = 'NEXT'
export const SUBMIT = 'SUBMIT'