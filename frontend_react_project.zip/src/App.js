import React, { Component } from 'react';
import './App.css';
import ClaimSummarCard from './components/ClaimSummarCard';
import { Provider } from 'react-redux';
import store from './redux/store/store';
import { Link, Route, BrowserRouter, Switch, Redirect } from 'react-router-dom'
import ClaimInfoForm1 from './components/ClaimInfoForm1'
import ClaimInfoForm2 from './components/ClaimInfoForm2'
import WizardForm from './components/WizardForm';

class App extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
       flag : false
    }
  }
  
  render() {
    let redirectToSummery; 

    if( !this.state.flag ){
      redirectToSummery = <Redirect to={ClaimSummarCard} />
    }
    return (
      <Provider store = {store}>
        <div className="App">
          
          <BrowserRouter> 
              <Link to="/"></Link>
              <Route exact path="/" component={ClaimSummarCard} />    
              {redirectToSummery}                            
              <Route path="/updateClaimDetails" component={WizardForm} />
              <Link to="/updateClaimDetails" className="link-form" >update claim details</Link>     
          </BrowserRouter>
          
        </div>
      </Provider>
    );
  }
}

export default App;
