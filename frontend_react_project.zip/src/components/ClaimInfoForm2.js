import React, { useState } from 'react'
import Footer from './Footer'

function ClaimInfoForm2(props) {
    const [workDetails, setWorkDetails] = useState({
        "doh": "2020-12-25",
        "rtw": "2020-08-20",
        "salary": 20000,
        "fda":"2020-08-01"
    });
    const {onSubmit}=props
    return (
        <div className="upper-form">
            <form onSubmit={onSubmit}>
                <table>
                <tr>
                    <td>
                        <li>
                            <div>
                                <label>
                                    Date of Hire
                                    <div className="sub-element">
                                        <input 
                                            type="date" 
                                            name="doh"
                                            value={workDetails.doh}
                                        />
                                    </div>
                                </label>
                            </div>
                            <div>
                                <label>
                                    Return to Work
                                    <div className="sub-element">
                                        <input 
                                            type="date" 
                                            name="rtw"
                                            value={workDetails.rtw}
                                        />
                                    </div>
                                </label>
                            </div>
                        </li>
                    </td>
                </tr>
                <tr>
                    <td>
                        <li>
                            <div>
                                <label>
                                    Salary
                                    <div className="sub-element">
                                        <input 
                                            type="text" 
                                            name="salary"
                                            value={workDetails.salary}
                                        />
                                    </div>
                                </label>
                            </div>
                            <div>
                                <label>
                                    First Day Absent
                                    <div className="sub-element">
                                        <input 
                                            type="date" 
                                            name="fda"
                                            value={workDetails.fda}
                                        />
                                    </div>
                                </label>
                            </div>
                        </li>
                    </td>
                </tr>
                <tr>
                    <div className="button-style">
                        <td>
                            <Footer title="CANCEL" type="cancel" />
                        </td>
                        <td>
                            <Footer title="SUBMIT" type="submit" />
                        </td>
                        
                    </div>
                </tr>
                </table>
                    
            </form>
            
        </div>
    )
}

export default ClaimInfoForm2
