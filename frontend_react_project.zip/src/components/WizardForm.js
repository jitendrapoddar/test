import React, { Component } from 'react'
import ClaimInfoForm1 from './ClaimInfoForm1'
import ClaimInfoForm2 from './ClaimInfoForm2'
import propTypes from 'prop-types'
import ClaimSummarCard from './ClaimSummarCard'

class WizardForm extends Component {
    constructor(props) {
        super(props)
        this.nextPage = this.nextPage.bind(this)
        this.previousPage = this.previousPage.bind(this)
        this.state = {
          page: 1
        }
      }

      nextPage() {
        this.setState({ page: this.state.page + 1 })
      }
    
      previousPage() {
        this.setState({ page: this.state.page - 1 })
      }

    render() {
        console.log('in wizardForm comp')
        const { onSubmit } = this.props
        const { page } = this.state
        return (
            <div>
                <div>
                    
                    {page === 1 && <ClaimInfoForm1 
                                        previousPage={this.previousPage}
                                        onSubmit={this.nextPage} />}
                    {page === 2 && (
                        <ClaimInfoForm2
                            previousPage={this.previousPage}
                            onSubmit={onSubmit}
                        />
                    )}
                    {page === 0 && <ClaimSummarCard />}                    
                </div>
            </div>
        )
    }
}

WizardForm.propTypes = {
    onSubmit: propTypes.func.isRequired
  }

export default WizardForm
