import React from 'react'

function ReduxDatePicker() {
    return (
        <div>
            <input type="date" />
        </div>
    )
}

export default ReduxDatePicker
