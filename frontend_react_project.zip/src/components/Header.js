import React from 'react'

function Header() {
    return (
        <div>
            <header>
                Header
            </header>
        </div>
    )
}

export default Header
