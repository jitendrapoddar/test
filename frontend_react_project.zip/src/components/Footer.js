import React from 'react'
import '../style/claiminfoform1.css'

function Footer(props) {
    
    return (
        <div>
            <footer>
                <button type={props.type} onClick = {props.redirectHandler}>{props.title}</button>
            </footer>
        </div>
    )
}

export default Footer
