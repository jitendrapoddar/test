import React from 'react'
import { connect } from 'react-redux'

import '../style/claimsummarycard.css'

function ClaimSummarCard(props) {
    console.log(props)
    return (
        <div>
            <header>
                <h1>{props.claimSummaryCardHeader}</h1>
            </header>
            <table>
                <tr>
                    <td>Employee Name</td>
                    <td>{props.employeeName}</td>
                </tr>
                <tr>
                    <td>Claim Number</td>
                    <td>{props.claimNumber}</td>
                </tr>
                <tr>
                    <td>Claim Type</td>
                    <td>{props.claimType}</td>
                </tr>
                <tr>
                    <td>Claim Programs</td>
                    <td>{props.claimPrograms}</td>
                </tr>
                <tr>
                    <td>Claim Start Date</td>
                    <td>{props.claimStartDate}</td>
                </tr>
                <tr>
                    <td>Claim End Date</td>
                    <td>{props.claimEndDate}</td>
                </tr>       
                         
            </table>
                
            
        </div>
    )
}

const mapStateToProps = state => {
    return{
        claimSummaryCardHeader : state.claimSummaryCardHeader,
        employeeName : state.employeeName,
        claimNumber : state.claimNumber,
        claimType : state.claimType,
        claimPrograms : state.claimPrograms,
        claimStartDate : state.claimStartDate,
        claimEndDate : state.claimEndDate
    }
}

export default connect(
    mapStateToProps
)(ClaimSummarCard)
