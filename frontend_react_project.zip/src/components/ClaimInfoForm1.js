import React, { useState } from 'react'
import { connect } from 'react-redux'
import PhoneInput from 'react-phone-input-2'
import '../style/claiminfoform1.css'
import Footer from './Footer'
import { Field, reduxForm } from 'redux-form'
import ReduxDatePicker from './ReduxDatePicker'
import validate from './validate.js'
import ClaimInfoForm2 from './ClaimInfoForm2'
import ClaimSummarCard from './ClaimSummarCard'

function ClaimInfoForm1(props) {

    const [page, setPage] = useState(1)
    const [personalDetails, setPersonalDetails] = useState({
        "firstName": "Jitendra",
        "middleName": "NA",
        "lastName": "kumar",
        "suffix": "poddar",
        "dob": "1993-08-01" ,
        "gender" : "male",
        "empid":"15667",
        "address":"gachibowli",
        "city":"hyd",
        "state":"ts",
        "zip":"50032",
        "phone":"912823298878"
    });

    

    const {onSubmit}=props
    return (
        <div className="upper-form">
            <form onSubmit={onSubmit}>
                <table>
                <ul>
                    <tr>
                    <li >
                        <td><label>Prefix</label></td>  
                        <td>
                            <div>
                                <select name="prefix">
                                    <option selected value="Mr.">Mr.</option>
                                    <option value="Mrs.">Mrs.</option>
                                    <option value="Ms.">Ms.</option>
                                </select>
                            </div>
                        </td>                    
                    </li>
                    </tr>
                    <tr>
                    <td>
                        <li>
                            <label> First Name
                                <div className="sub-element">
                                    <input 
                                        name="firstName" 
                                        type="text" 
                                        value={personalDetails.firstName}
                                        placeholder="First Name"/>
                                </div>
                            </label>
                            <label>Middle Name
                                <div className="sub-element">
                                    <input 
                                        name="middleName" 
                                        type="text" 
                                        value={personalDetails.middleName}
                                        placeholder="Middle Name"/>
                                </div>
                            </label>
                            <label> Last Name
                                <div className="sub-element">
                                    <input 
                                        name="lastName" 
                                        type="text" 
                                        value={personalDetails.lastName}
                                        placeholder="Last Name"/>
                                </div>
                            </label>
                        </li>
                    </td>
                    </tr>
                    <tr>
                        <li>
                            <td><label>
                                Suffix                            
                                <div className="sub-element">
                                <input 
                                    name="suffix" 
                                    type="text" 
                                    value={personalDetails.suffix}
                                    placeholder="your title"/>
                                </div>
                                </label>
                            </td>
                        </li>
                    </tr>
                    <tr>
                        <td>
                            <li>
                                <label>
                                    Date of Birth
                                    <div className="sub-element">
                                        <input
                                            name="dob"
                                            value={personalDetails.dob}
                                            type="date"
                                        />
                                    </div>
                                </label>
                                <label>
                                    Gender
                                    <div className="sub-element">
                                        <select name="gender" value={personalDetails.gender}>
                                            <option value="male">male</option>
                                            <option value="female">female</option>
                                            <option value="others">others</option>
                                        </select>
                                    </div>
                                </label>                            
                            </li>
                        </td>  
                    </tr>                      
                    <tr>
                    <li>
                        <td><label> 
                            Employee ID
                        <div className="sub-element">
                            <input 
                                name="empid" 
                                type="text" 
                                value={personalDetails.empid}
                                placeholder="Employee ID"/>
                        </div>
                        </label>
                        </td>                        
                    </li>
                    </tr>
                    <tr>
                    <li>
                        <td><label>Address</label></td>
                        <td>
                        <div>
                        <textarea 
                                name="address" 
                                value={personalDetails.address}
                                placeholder="Address"/>
                        </div>
                        </td>                        
                    </li>
                    </tr>
                    <tr>
                        <td>
                    <li>
                        <label>
                            City
                            <div className="sub-element">
                            <input 
                                name="city" 
                                type="text" 
                                value={personalDetails.city}
                                placeholder="city"/>
                            </div>
                        </label>
                    
                        <label>
                            State
                            <div className="sub-element">
                            <input 
                                name="state" 
                                type="text" 
                                value={personalDetails.state}
                                placeholder="state"/>
                            </div>
                        </label>
                    
                        <label>
                            Zip
                            <div className="sub-element">
                            <input 
                                name="zip" 
                                type="text" 
                                value={personalDetails.zip}
                                placeholder="zip"/>
                            </div>
                        </label>
                    </li>
                    </td>
                    </tr>
                    <tr>
                    <li>
                        <td><label> Contact</label></td>
                        <td>
                        <PhoneInput 
                            name="phone"
                            value={personalDetails.phone}
                            placeholder = "Enter Phone Number" />
                        </td>
                    </li>
                    </tr>
                </ul>
                <tr>
                <div className="button-style">
                    <td>
                        <Footer title="CANCEL" type="cancel" onClick={e => setPage(e.target.value - 1)}/>
                    </td>
                    <td>
                        <Footer title="NEXT" type="submit" onClick={e => setPage(e.target.value + 1)}/>
                    </td>
                </div>
                </tr>
                </table>
                
            </form>


            {page === 0 ? <ClaimSummarCard /> : (page === 2 ? <ClaimInfoForm2 /> :  null)}
        </div>
    )
}

const mapStateToProps = state => {
    return{
        claimSummaryCardHeader : state.claimSummaryCardHeader,
        employeeName : state.employeeName,
        claimNumber : state.claimNumber,
        claimType : state.claimType,
        claimPrograms : state.claimPrograms,
        claimStartDate : state.claimStartDate,
        claimEndDate : state.claimEndDate
    }
}

export default connect(
    mapStateToProps
)(ClaimInfoForm1)

    
