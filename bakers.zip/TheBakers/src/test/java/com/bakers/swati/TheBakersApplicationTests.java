package com.bakers.swati;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.bakers.swati.entity.BakeryStore;
import com.bakers.swati.repository.BakeryRepository;

@SpringBootTest
class TheBakersApplicationTests {
	
	@Autowired
	BakeryRepository bakeryRepository;

	@Test
	void contextLoads() {
		bakeryRepository.save(new BakeryStore(002, "Butter-scoch Cake", "BC002", 400.00 ));
	}

}
