package com.bakers.swati.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class BakeryStore {
	
	@Id
	public int itemId;
	public String name;
	public String code;
	public Double price;
	
	
	public BakeryStore() {
		
	}
	
	public BakeryStore(int itemId, String name, String code, Double price) {
		super();
		this.itemId = itemId;
		this.name = name;
		this.code = code;
		this.price = price;
	}
	
	
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	
	
	
	

}
