package com.bakers.swati;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheBakersApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheBakersApplication.class, args);
	}

}
