package com.bakers.swati.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.bakers.swati.entity.BakeryStore;

public interface BakeryRepository extends MongoRepository<BakeryStore, Integer> {

}
