package com.bakers.swati.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bakers.swati.entity.BakeryStore;
import com.bakers.swati.services.BakeryServices;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@RestController
@RequestMapping("/api/the-bakers")
public class TheBakeryResource {
	
	@Autowired
	BakeryServices bakeryServices;

	@GetMapping("/all-items")
	@CrossOrigin(origins = "http://localhost:3000")
	List<BakeryStore> getAllBakeryProducts(){
		return bakeryServices.fetchAllItems();
	}
	
	@GetMapping("/item/{id}")
	@CrossOrigin(origins = "http://localhost:3000")
	BakeryStore getBakeryProductById(@PathVariable("id") int id) {
		return bakeryServices.fetchItem(id);
	}
	
	@PostMapping("/addItem")
	@CrossOrigin(origins = "http://localhost:3000")
	int addBakeryProduct(@RequestBody BakeryStore bakeryStore) {
		return bakeryServices.addItem(bakeryStore);
	}

}
