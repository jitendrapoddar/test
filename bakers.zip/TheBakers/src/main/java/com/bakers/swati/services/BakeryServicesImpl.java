package com.bakers.swati.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bakers.swati.entity.BakeryStore;
import com.bakers.swati.repository.BakeryRepository;

@Service
public class BakeryServicesImpl implements BakeryServices {

	@Autowired
	BakeryRepository bakeryRepository;

	@Override
	public List<BakeryStore> fetchAllItems() {
		return bakeryRepository.findAll();
	}

	@Override
	public BakeryStore fetchItem(int id) {
		// TODO Auto-generated method stub
		return bakeryRepository.findById(id).get();
	}

	@Override
	public int addItem(BakeryStore bakeryStore) {

		BakeryStore store = bakeryRepository.save(bakeryStore);
		return store.itemId;

	}

}
