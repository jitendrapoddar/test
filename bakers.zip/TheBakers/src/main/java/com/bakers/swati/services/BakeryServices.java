package com.bakers.swati.services;

import java.util.List;


import com.bakers.swati.entity.BakeryStore;


public interface BakeryServices {
	
	List<BakeryStore> fetchAllItems();
	BakeryStore fetchItem(int id);
	int addItem(BakeryStore bakeryStore);
	

}
