import React from 'react';
import './App.css';
import CakeContainer from './component/CakeContainer';
import NewCakeContainer from './component/NewCakeContainer';
import HooksCakeContainer from './component/HooksCakeContainer';
import IceCreamContainer from './component/iceCreamContainer'
import ItemContainer from './component/ItemContainer'
import UserContainer from './component/UserContainer'
import store from './redux/store';
import { Provider } from 'react-redux'

function App() {
  return (
    <Provider store = {store}>
        <div>
        <CakeContainer />
          <UserContainer />
         
        </div>

    </Provider>
    
  );
}

export default App;
